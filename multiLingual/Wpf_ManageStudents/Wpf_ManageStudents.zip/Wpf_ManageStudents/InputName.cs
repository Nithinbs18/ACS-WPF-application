﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wpf_ManageStudents
{
    public class InputName
    {
        public string name { get; set; }
        public string category { get; set; }
    }
}
